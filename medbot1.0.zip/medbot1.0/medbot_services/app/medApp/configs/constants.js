var constants = {
	"PAGE_ACCESS_TOKEN":"EAAHaSVKyKGABAL4M68MU4UZBekx1Tnb62nBiLNqCZBJlva3wUnKxR4pJXwrvRWHeBO0KKGI3zPdUJDRiDEETHeQmhh8vtdRXfrtc6uZCrDkDCV6Ns6o9HohftZBauNww7KlGY6uMdy2daXIaSUOw698fjWE0qgZBnFUUdm9nn2AZDZD",
	"VERIFICATION_TOKEN":"medicalbottoken123",
	"FLASK_SERVICE_URL": "https://test-medbot-flaskservice.herokuapp.com"
}

module.exports = constants