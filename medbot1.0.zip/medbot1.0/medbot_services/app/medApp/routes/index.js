var express = require("express");
var request = require("request");
var rp = require("request-promise")
var fs = require("fs")
var bodyParser = require("body-parser");
var querystring = require("querystring");
var constants = require('../configs/constants')
var ConversationalStateStore = require('../services/ConversationalStateStore')
var store = new ConversationalStateStore()
store.getMap()

//var app = express();
var router = express.Router();
var tests = fs.readFileSync("tests.json")
var tests_json = JSON.parse(tests);
var queue = [];
var matchedTestObject; 

var numericInputs = {}
// Server index page
router.get("/", function (req, res) {
	var map = store.getMap()
	res.send({"stateStore":map});
});


// Facebook Webhook
// Used for verification
router.get("/webhook", function (req, res) {
	if (req.query["hub.verify_token"] === constants.VERIFICATION_TOKEN) {
		console.log("Verified webhook");
		res.status(200).send(req.query["hub.challenge"]);
	} else {
		console.error("Verification failed. The tokens do not match.");
		res.sendStatus(403);
	}
});


router.get('/tests', function(req, res) {
	res.send(tests_json)
})

router.get("/symptom", function(req, res) {
	request(constants.FLASK_SERVICE_URL)
});

// All callbacks for Messenger will be POST-ed here
router.post("/webhook", function (req, res) {
	// Make sure this is a page subscription
	if (req.body.object == "page") {
		// Iterate over each entry
		// There may be multiple entries if batched
		req.body.entry.forEach(function(entry) {
			// Iterate over each messaging event
			entry.messaging.forEach(function(event) {
				if (event.postback) {
					processPostback(event);
				}else if (event.message) {
					processMessage(event);
				}
			});
		});

		res.sendStatus(200);
	}
});

function processPostback(event) {
	var senderId = event.sender.id;
	var payload = event.postback.payload;

	if (payload === "Greeting") {
		// Get user's first name from the User Profile API
		// and include it in the greeting
		request({
			url: "https://graph.facebook.com/v2.6/" + senderId,
			qs: {
				access_token: constants.PAGE_ACCESS_TOKEN,
				fields: "first_name"
			},
			method: "GET"
		}, function(error, response, body) {
			var greeting = "";
			if (error) {
				console.log("Error getting user's name: " +  error);
			} else {
				var bodyObj = JSON.parse(body);
				name = bodyObj.first_name;
				greeting = "Hi " + name + ". ";
			}
			var message = greeting + "I am a Medical Bot. I can help in diagnosing your symptoms. Tell me your symptoms one by one";
			sendMessage(senderId, {text: message});
		});
	}
}

async function processMessage(event) {
	if (!event.message.is_echo) {
		var message = event.message;
		var senderId = event.sender.id;
		var response = "";

		console.log("Received message from senderId: " + senderId);
		console.log("Message is: " + JSON.stringify(message));

		// You may get a text or attachment but not both
		if (message.text) {
			if(!isNaN(message.text)){
				console.log("Number received: " + message.text);
				//extract context
				var state = store.getState(senderId);
				var contextualState = store.getContextualStates(senderId);
				if (!numericInputs[matchedTestObject.tag]) {
					numericInputs[matchedTestObject.tag] = [];
				}
				numericInputs[matchedTestObject.tag].push(message.text);
				if(queue.length > 0){
					response = matchedTestObject.questions[queue.shift()];
				} else{
					//process responses
					console.log("## numeric inputs ##", numericInputs[matchedTestObject.tag]);
					var resVal = numericInputs[matchedTestObject.tag].reduce((a,b)=>(parseInt(a)+parseInt(b)),0); 
					console.log("## Result value ##", resVal)
					if (resVal > 500) {
						response = "You're sick as fuck, bro."
					} else {
						response = "You're healthy as fuck, bro.";
					}

					numericInputs[matchedTestObject.tag] = [];
					
				}
				//load data structure with questions
			} else{
				console.log("Message received: " + message.text);
				response = await getIntent(senderId, message.text);
			}
			sendMessage(senderId, {text: response});
		} else if (message.attachments) {
			sendMessage(senderId, {text: "Sorry, I don't understand your request."});
		}
	}
}

async function getIntent(senderId, message) {

	var options = {
		method: "GET",
		uri: constants.FLASK_SERVICE_URL+"/getIntent",
		qs: {
			value:message
		},
		json: true
	};

	await rp(options)
	.then(async function (response) {
		console.log("--- In Node :: Printing response ---");
		console.log(response);
		store.setState(senderId, response.intent, response.result)
		var isExpectationMetWithMessage = store.matchExpectation(senderId, message); 
		var isExpectationMetWithIntent = store.matchExpectation(senderId, response.intent); 

		if (isExpectationMetWithMessage) {

			console.log("## Expectation met with message ##\n");
			console.log("## Response -- intent : "+response.intent+" response : "+response.result+" ##\n");

			if(response.intent === "TESTS"){
				store.setContextualState(senderId, response.intent);
				console.log("## Inside TESTS ##\n");
				nqResponse = await getNextReportQuestion(message);
				str = nqResponse;

			}else{
				store.setContextualState(senderId, message);
				nextQuestionResult = await getNextQuestion(message);
				store.setState(senderId, nextQuestionResult.intent, nextQuestionResult.result);
				store.setExpectation(senderId, nextQuestionResult.intent);
				nqResponse = "Are you suffering from any of these symptoms as well?\n"; 
				nqResponse += prettyFormatSymptoms(nextQuestionResult.result);
				str = nqResponse;
			}

		} else if (isExpectationMetWithIntent) {
			console.log("## Expectation met with intent ##", response.intent);
			//decipher which entity does it match to and then, 
			//trigger next question algorithm with matched entity
			str = "You can die then.";
		} else if (response.intent === "SYMPTOM_DETECTION") {
			sdResponse = "Which of these symptoms describe what you said best?\n";
			sdResponse += prettyFormatSymptoms(response.result)
			store.setExpectation(senderId, response.intent)
			str = sdResponse;
		} else if (response.intent === "REPORT") {
			sdResponse = "Which of these tests do you want help with?\n";
			sdResponse += response.result
			store.setExpectation(senderId, response.intent)
			str = sdResponse;
		} else if(response.intent === "TESTS"){
				store.setContextualState(senderId, response.intent);
				console.log("## Inside TESTS ##\n");
				nqResponse = getNextReportQuestion(message);
				str = nqResponse;

		} else if (response.intent === "NEXT_QUESTION") {
			nqResponse = "Are you suffering from any of these symptoms as well?\n"; 
			nqResponse += prettyFormatSymptoms(nextQuestionResult.result)
			store.setExpectation(senderId, response.intent)
			str = nqResponse;

			/*

				This particular algorithm will keep on calling next question on a loop until 
				TODO: all of the next questions symptom are in the context states already OR 
				TODO: user invokes the close intent saying "that's all or that's enough or done"
					After this all contextualStates are sent to guessDisease method. 
					Flush all states for the user. 
				DONE  

			*/
		} else if (response.intent === "CLOSE_STATE") {
			var symptomsList = store.getContextualStates(senderId)
			guessDiseaseResult = await getGuessDisease(symptomsList)
			console.log("#### printing response from guess disease flow ####")
			console.log(guessDiseaseResult)
			console.log("#### end response ####")
			gdResponse = "According to my differential diagnoses, it looks like you maybe suffering from one of these ailments.\n\n";
			gdResponse += guessDiseaseResult.result.join("\n\n")
			gdResponse += "\n\nPlease consult with your physician for better understanding and treatment."
			str = gdResponse
			store.flushState(senderId)
		} else {
			str = JSON.stringify(response.result);
			store.flushState(senderId)
		}
				
	})
	.catch(function (error) {
		// API call failed...
		console.log("-- Printing error --");
		console.log(error);
		str = "Sorry, I didn't understand. Can you say it in a different way?";
		store.flushState(senderId)
	});
	return str;
}

function prettyFormatSymptoms(symptomsObj) {
	sdResponse = "\n";
	for (var key in symptomsObj) {
		if (symptomsObj.hasOwnProperty(key)) {
			sdResponse += key+": "+symptomsObj[key]+"\n"
		}
	}
	return sdResponse; 
} 


async function getNextQuestion(symptomName) {
	var str; 
	var options = {
		method: "GET",
		uri: constants.FLASK_SERVICE_URL+"/getNextQuestion",
		qs: {
			sid:symptomName
		},
		json: true
	};
	await rp(options)
		.then(function(response) {
			str = response;
		}).catch(function(error) {
			throw new Error("Next question failed to execute")
		})

	return str;
}

function getNextReportQuestion(testname) {
	console.log("## Inside getNextReportQuestion ##\n");
	
	queue = [];
	console.log("File : \n");
	console.log(tests_json);
	var tests = tests_json.tests;

	for(item in tests_json){
		console.log("## tests = ##"+tests);
		for(subitem in tests){
			var value = tests[subitem]['tag']
			console.log("## Value = ##"+value);
			if(value == testname){
				matchedTestObject = tests[subitem];
				for(question in tests[subitem]['questions']){
					console.log("## Ques = ##"+question);
					queue.push(question);
				}
				break;
			}
		}
	}


	console.log("## Queue is : "+queue+" ##\n");
	var str = queue.shift();
	return matchedTestObject.questions[str];
}

async function getGuessDisease(symptomNames) {
	var str; 
	var options = {
		method: "GET",
		uri: constants.FLASK_SERVICE_URL+"/getGuessDisease",
		qs: {
			sids:symptomNames.join(",")
		},
		json: true
	};
	await rp(options)
		.then(function(response) {
			str = response;
		}).catch(function(error) {
			throw new Error("Next question failed to execute")
		})

	return str;
}
// sends message to user
function sendMessage(recipientId, message) {
	console.log("--- Sending message --- ")
	console.log("message", message)
	request({
		url: "https://graph.facebook.com/v2.6/me/messages",
		qs: {access_token: constants.PAGE_ACCESS_TOKEN},
		method: "POST",
		json: {
			recipient: {id: recipientId},
			message: message,
		}
	}, function(error, response, body) {
		if (error) {
			console.log("Error sending message: " + response.error);
		}
	});
}

module.exports = router;
