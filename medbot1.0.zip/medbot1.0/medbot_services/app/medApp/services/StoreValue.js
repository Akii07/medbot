var StoreValue = function() {
	this.contextualStates = []; 
	this.expects = [];
	this.states = [];
}

module.exports = StoreValue; 