var State = require('./State')

var ConversationalStateFactory = function() {
	this.createState = function(intent, value) {
		return new State(intent, value)
	}
}

module.exports = ConversationalStateFactory


