
var State = function(intent, value) {
	this.intent = intent
	this.value = value
} 

module.exports = State