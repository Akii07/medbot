var ConversationalStateFactory = require('./ConversationalStateFactory')
var StoreValue = require('./StoreValue')

var ConversationalStateStore = function() {
	var map; 
	var factory = new ConversationalStateFactory()
	function createMap() {
		var object = {}
		return object
	}

	return {
		getMap: function() {
			if (!map) {
				map = createMap()
			}
			return map;
		},
		setState: function(senderId, intent, value) {
			if(!map[senderId]) {
				map[senderId] = new StoreValue()
			} 
			
			map[senderId].states.push(factory.createState(intent, value));
			
		}, 
		getState: function(senderId) {
			if (!map[senderId]) {
				map[senderId] = new StoreValue()
			}
			return map[senderId]; 
		},
		setExpectation: function(senderId, expectType) {
			console.log("## Setting expectation ##")
			console.log(senderId, expectType)
			if (!map[senderId]) {
				return null;
			}
			this.flushExpectations(senderId)
			if (expectType === "SYMPTOM_DETECTION" || expectType === "NEXT_QUESTION") {
				var lastMessageState = map[senderId].states.slice(-1).pop().value
				for (var key in lastMessageState) {
					if (lastMessageState.hasOwnProperty(key)) {
						map[senderId].expects.push(key.toUpperCase())
					}
				}
				map[senderId].expects.push("FIRST_ONE","SECOND_ONE","THIRD_ONE","BOTH","ALL","FIRST_SECOND_ONE","FIRST_THIRD_ONE","SECOND_THIRD_ONE")

			}else if (expectType === "REPORT") {
				var lastMessageState = map[senderId].states.slice(-1).pop().value
				// map[senderId].expects.push(key.toUpperCase())
				// for (var i in lastMessageState){
				// 	map[senderId].expects.push(i.toUpperCase())
				// }
			}
		}, 
		matchExpectation: function(senderId, intentOrArgument) {
			if (!map[senderId]) {
				return false;
			}
			return map[senderId].expects.indexOf(intentOrArgument.toUpperCase()) !== -1
		},

		setContextualState: function(senderId, contextualState) {
			if (map[senderId] && map[senderId].contextualStates.indexOf(contextualState) === -1) {
				map[senderId].contextualStates.push(contextualState)
			}
		},

		getContextualStates: function(senderId) {
			if (!map[senderId]) return null; 
			return map[senderId].contextualStates
		},



		flushExpectations: function(senderId) {
			if (map[senderId]) {
				map[senderId].expects = []
			}
		},
		flushState: function(senderId) {
			map[senderId] = null
		}
	}
}

module.exports = ConversationalStateStore
