import csv
import json
from nltk.corpus import stopwords
from nltk.tokenize import RegexpTokenizer
from nltk.stem.lancaster import LancasterStemmer
import numpy as np
import nltk
import tflearn
import tensorflow as tf
import random
import pickle
import os,sys
from flask import Flask,request,jsonify

app = Flask(__name__)

stemmer = LancasterStemmer()



i_data = pickle.load( open( "training_data_intent", "rb" ) )
i_words = i_data['words']
i_classes = i_data['classes']
i_train_x = i_data['train_x']
i_train_y = i_data['train_y']

nq_data = pickle.load( open("next_ques_data", "rb") )
mapSymptoms = nq_data['mapSymptoms']
mapDiseases = nq_data['mapDiseases']
mapSymptomIds = nq_data['mapSymptomIds']
mapDiseaseIds = nq_data['mapDiseaseIds']
s2s = nq_data['s2s']
s2d = nq_data['s2d']
s_occurrence = nq_data['s_occurrence']
d_occurrence = nq_data['d_occurrence']
flat_symptoms = nq_data['flat_symptoms']
flat_diseases = nq_data['flat_diseases']

# import our chat-bot intents file
with open('intents.json') as json_data:
	intents = json.load(json_data)

file = open('symptoms.txt','r')

symptoms = {}
NGRAM_N = 3
ACCEPTABLE_LIMIT = 0.05

for line in file: 
	line = line.replace('\n','')
	sym = line.split("]][[")
	if (len(sym) > 1):
		symptoms[sym[0]] = sym[1]


#print(symptoms)

def ngrams(input, n):
  #input = input.split()
  output = []
  input = input.replace(' ','')
  input = input.replace(',','')
  for i in range(len(input)-n+1):
    output.append(input[i:i+n])
  return output


def intersection(lst1, lst2):
    lst3 = [value for value in lst1 if value in lst2]
    return lst3

def union(lst1, lst2):
    final_list = lst1 + lst2
    return final_list

def _jaccard(lst1, lst2): 
	intersectionVal = intersection(lst1, lst2)
	unionVal = union(lst1, lst2)
	return float(len(intersectionVal))/float(len(unionVal))

symptoms_ngrams = {}

def get_symptoms_ngrams():
	for k,v in symptoms.items():
		n_sym = ngrams(k+v, NGRAM_N)
		symptoms_ngrams[k] = n_sym

get_symptoms_ngrams()


def get_jaccard_vector(input): 
	result_map = {}
	print("User asks:", input)
	n_input = ngrams(input, NGRAM_N)
	for k,v in symptoms_ngrams.items():
		val = _jaccard(n_input, v)
		if (val > ACCEPTABLE_LIMIT):
			result_map[k] = val

	result = [(k, result_map[k]) for k in sorted(result_map, key=result_map.get, reverse=True)][0:5]

	return [r[0] for r in result]


def evaluate_symptom_detection(str): 
	syms = get_jaccard_vector(str)
	r_dict = {}
	for s in syms: 
		r_dict[s] = symptoms[s]

	return r_dict

# load our saved model


tf.reset_default_graph()
i_net = tflearn.input_data(shape=[None, len(i_train_x[0])])
i_net = tflearn.fully_connected(i_net, 8)
i_net = tflearn.fully_connected(i_net, 8)
i_net = tflearn.fully_connected(i_net, len(i_train_y[0]), activation='softmax')
i_net = tflearn.regression(i_net)
i_model = tflearn.DNN(i_net, tensorboard_dir='tflearn_intent_logs')
i_model.load('./model.intent')

def clean_up_sentence(sentence):
    # tokenize the pattern
    sentence_words = nltk.word_tokenize(sentence)
    # stem each word
    sentence_words = [stemmer.stem(word.lower()) for word in sentence_words]
    return sentence_words

# return bag of words array: 0 or 1 for each word in the bag that exists in the sentence
def bow(sentence, words, show_details=False):
    # tokenize the pattern
    sentence_words = clean_up_sentence(sentence)
    # bag of words
    bag = [0]*len(words)  
    for s in sentence_words:
        for i,w in enumerate(words):
            if w == s: 
                bag[i] = 1
                if show_details:
                    print ("found in bag: %s" % w)

    return(np.array(bag))

ERROR_THRESHOLD = 0.01
def classifySymptom(sentence):
    # generate probabilities from the model
    return evaluate_symptom_detection(sentence)

ERROR_THRESHOLD = 0.025
def classifyIntent(sentence):
    # generate probabilities from the model
    results = i_model.predict([bow(sentence, i_words)])[0]
    # filter out predictions below a threshold
    results = [[i,r] for i,r in enumerate(results) if r>ERROR_THRESHOLD]
    # sort by strength of probability
    results.sort(key=lambda x: x[1], reverse=True)
    return_list = []
    for r in results:
    	return_list.append(i_classes[r[0]])
        # return_list.append((classes[r[0]], r[1]))
    # return tuple of intent and probability
    return return_list[0]

def getIntentResponse(sentence, show_details=False):
	returnVal = None
	result = classifyIntent(sentence)
	print("#######  In Python :: Identified Intent ######")
	print(result)
	if (result == 'identification'):
		print("calling symptom deduction")
		response = classifySymptom(sentence)
		print("###### Python :: Symptom Detector Response ######")
		print(response)
		returnVal = [response, 'SYMPTOM_DETECTION']
	else:
		for i in intents['intents']:
			if i['tag'] == result:
				if i['tag'] in ["info", "affirmative_yes", "affirmative_no","first_one","second_one","third_one","first_second_one","first_third_one","second_third_one","both","all","close_state"]:
					print("## value in list##")
					value = i['responses']
				elif (i['tag'] == "report"):
					value = i['tests']
				else:
					print("## value not in list##")
					value = random.choice(i['responses'])
				print("###### Python :: Printing i ######")
				print(i['tag'])
				print("###### Python :: Intent Response ######")
				print(value)
				returnVal = [value, i['tag'].upper()]
				print(returnVal)
	return returnVal


def next_question_by_name(symptom_name):
	print("Evaluating next_question for ", symptom_name)
	sid = mapSymptoms[symptom_name]
	return next_question(sid)


def next_question(sid):
	print("Next question for ", sid, evaluate_symptom(sid))
	#get the related mapped symptoms for this 
	result = []
	related_symptoms =  s2s[sid]
	count_dict = {}
	for each_symptom in related_symptoms: 
		count_dict[each_symptom] = s_occurrence[each_symptom]

	count_dict = [(k, count_dict[k]) for k in sorted(count_dict, key=count_dict.get, reverse=True)]
	for item in count_dict: 
		result.append(item[0])

	result = result[0:3]
	print("Do you also have ", evaluate_symptom_list(result))
	print("Result symptom ids", result)
	result_names = evaluate_symptom_list(result)
	r_dict = {}
	for s in result_names:
		s = s.encode('utf-8') #because pickle file has screwed up encoding.
		r_dict[s] = symptoms[s]
	return r_dict

def guess_disease_by_symptom_name(symptom_names):
	print("Evaluating guess_disease for", symptom_names)

	sids = [s.encode('utf-8') for s in symptom_names]
	sids = [" ".join([s[0].upper()+s[1:len(s)] for s in sid.split()]) for sid in sids]
	sids = [mapSymptoms[sid] for sid in sids]
	print(sids)
	return guess_disease(sids)

def guess_disease(sids):
	print("Evaluating for ", evaluate_symptom_list(sids))
	print("Symptom ids", sids)
	final = []
	result = {}
	base = 'false'
	for sid in sids: 
		list_diseases = s2d[sid]
		for disease in list_diseases: 
			if (disease not in d_occurrence): 
				list_diseases.remove(disease)
		result[sid] = list_diseases
		if (base != 'false'): 
			base = intersection(base, list_diseases)
		else: 
			base = list_diseases

	count_dict = {}
	for item in base: 
		count_dict[item] = d_occurrence[item]

	count_dict = [(k, count_dict[k]) for k in sorted(count_dict, key=count_dict.get, reverse=True)]
	for item in count_dict: 
		final.append(item[0])

	final = final[0:5]
	print("Results:", evaluate_disease_list(final))
	return evaluate_disease_list(final)
 

def evaluate_symptom(sid):
	return mapSymptomIds[sid]

def evaluate_disease(did):
	return mapDiseaseIds[did]

def evaluate_symptom_list(sids):
	result = []
	for sid in sids: 
		result.append(evaluate_symptom(sid))

	return result

def evaluate_disease_list(dids):
	result = [evaluate_disease(did) for did in dids]
	return result

@app.route('/')
def index():
	return 'OK'

@app.route('/getIntent')
def getIntent():
	val = request.args.get('value')
	print("#######  In Python :: printing received string ######")
	print(val)
	response = getIntentResponse(val)
	print("#######  In Python :: Returning response ######")
	print(response)
	# print(result)
	return jsonify(result=response[0], intent=response[1])
	

@app.route('/getSymptom')
def getSymptom():
	s = request.args.get('param')
	return jsonify(result=classifySymptom(s), intent="SYMPTOM_DETECTION")

@app.route('/getNextQuestion')
def getNextQuestion():
	sid = request.args.get('sid')
	sid = " ".join([s[0].upper()+s[1:len(s)] for s in sid.split()]) #super fancy python way of capitalizing just the first letter in each word of the string.
	print("#### Calling next question with name ####", sid)
	return jsonify(result=next_question_by_name(sid), intent="NEXT_QUESTION")

@app.route('/getGuessDisease')
def getGuessDisease():
	s= request.args.get('sids').split(',')
	return jsonify(result=guess_disease_by_symptom_name(s), intent="GUESS_DISEASE")

if __name__=="__main__":
	app.run()
	# app.run(debug=True,port=80)
