import requests
import json
import csv

def get_json(arg):
	l = []
	l.append(arg)
	filters = {"rows":172,"start":0,"symptoms":l}
	url = "https://frontend-prod.healthline.com/api/symptom-checker/conditions"
	response = requests.post(url, json=filters)
	data = response.json()
	try:
		c = 0
		conditions = []
		for i in data['conditions']:
			conditions.append(data['conditions'][c]['itemtitle'])
			print(arg+","+str(conditions[c]))
			c=c+1
		#print("summary : "+str(summary)+"\nbody : "+str(body)+"\nk1 : "+str(k1)+"\nk2 : "+str(k2)+"\nk3 : "+str(k3)+"\ncount : "+str(count)+"\nconditions : "+str(conditions)+"\nsymptoms : "+str(symptoms))
	except:
		try:
			res = data['error']
			print(arg+",error "+str(res))
		except:
			res = data['redirect']
			print(arg+", redirect "+str(res))

file = csv.reader(open('symptoms.csv'),delimiter=',')
for i in file:
	get_json(i[0])