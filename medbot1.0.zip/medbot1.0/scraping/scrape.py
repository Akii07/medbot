import requests
import json
import csv

def get_json(arg):
	l = []
	l.append(arg)
	filters = {"rows":172,"start":0,"symptoms":l}
	url = "https://frontend-prod.healthline.com/api/symptom-checker/conditions"
	response = requests.post(url, json=filters)
	print("\n"+str(l)+" : ")
	data = response.json()
	try:
		summary = data['article']['summary']
		body = data['article']['body']
		k1 = data['adTargeting']['targeting']['k1']
		k2 = data['adTargeting']['targeting']['k2']
		k3 = data['adTargeting']['targeting']['k3']
		count = data['conditionCount']
		c = 0
		conditions = []
		print("\nPossible Conditions : \n")
		for i in data['conditions']:
			conditions.append(data['conditions'][c]['itemtitle'])
			print(conditions[c])
			c=c+1
		c = 0
		symptoms = []
		print("\nRelated Symptoms : \n")
		for i in data['relatedSymptoms']:
			symptoms.append(data['relatedSymptoms'][c]['cfn'])
			print(symptoms[c])
			c=c+1
		#print("summary : "+str(summary)+"\nbody : "+str(body)+"\nk1 : "+str(k1)+"\nk2 : "+str(k2)+"\nk3 : "+str(k3)+"\ncount : "+str(count)+"\nconditions : "+str(conditions)+"\nsymptoms : "+str(symptoms))
	except:
		try:
			res = data['error']
		except:
			res = data['redirect']
		print(res)
	return data

file = csv.reader(open('symptoms.csv'),delimiter=',')
for i in file:
	result=get_json(i[0])