import csv

file = csv.reader(open('symptoms.csv'),delimiter=',')
f = open("symp.txt","w")
for i in file:
	f.write(str(i[0])+"\n")