import requests
import json
import csv
import re
from html.parser import HTMLParser


class MLStripper(HTMLParser):
    def __init__(self):
        self.reset()
        self.strict = False
        self.convert_charrefs= True
        self.fed = []
    def handle_data(self, d):
        self.fed.append(d)
    def get_data(self):
        return ''.join(self.fed)

def strip_tags(html):
    s = MLStripper()
    s.feed(html)
    return s.get_data()

def get_json(arg,f1,f2):
	l = []
	l.append(arg)
	filters = {"rows":500,"start":0,"symptoms":l}
	url = "https://frontend-prod.healthline.com/api/symptom-checker/conditions"
	response = requests.post(url, json=filters)
	data = response.json()
	try:
		name = data['symptomNames'][0]

		try:
			summary = data['article']['summary']
		except:
			summary = str(null)

		try:
			body = data['article']['body']
			dsc = strip_tags(body)
			desc = re.sub(r"[\n\t\r]*","", dsc)
			#desc = dsc.rstrip("\n\r")
		except:
			desc = "null"

		try:
			k1 = data['adTargeting']['targeting']['k1']
		except:
			k1 = "null"

		try:
			k2 = data['adTargeting']['targeting']['k2']
		except:
			k2 = "null"

		try:
			k3 = data['adTargeting']['targeting']['k3']
		except:
			k3 = "null"

		try:
			count = str(data['conditionCount'])
		except:
			count = "0"

		s = "insert into symptom(symptom_name,summary,symptom_desc,k1,k2,k3,disease_count) values('"+name+"','"+summary+"','"+desc+"','"+k1+"','"+k2+"','"+k3+"',"+count+");\n"
		f1.write(s)
	
	except:
		s = "error for "+str(l[0])+"\n"
		f2.write(s)
	
	return


file = csv.reader(open('symptoms.csv'),delimiter=',')
f1 = open("symptomsInsert.txt","w")
f2 = open("errorInsert.txt","w")
line = 0
for i in file:
	line += 1
	print(str(line))
	get_json(i[0],f1,f2)
	#f.write(s)
	# if line%10==0:
	# 	f.close()
	# 	f=open("symptomsInsert.txt","a+")
	# 	print("Opening file for write "+str(line))