import requests
import json
import csv
from html.parser import HTMLParser


class MLStripper(HTMLParser):
    def __init__(self):
        self.reset()
        self.strict = False
        self.convert_charrefs= True
        self.fed = []
    def handle_data(self, d):
        self.fed.append(d)
    def get_data(self):
        return ''.join(self.fed)

def strip_tags(html):
    s = MLStripper()
    s.feed(html)
    return s.get_data()

def get_json(arg):
	l = []
	l.append(arg)
	t = ['earache']
	filters = {"rows":500,"start":0,"symptoms":t}
	url = "https://frontend-prod.healthline.com/api/symptom-checker/conditions"
	response = requests.post(url, json=filters)
	data = response.json()
	try:
		n = data['symptomNames'][0]
		print(n)
		n = "hi"

		try:
			summary = data['article']['summary']
		except:
			summary = null

		try:
			body = data['article']['body']
			desc = strip_tags(body)
		except:
			desc = null

		try:
			k1 = data['adTargeting']['targeting']['k1']
		except:
			k1 = null

		try:
			k2 = data['adTargeting']['targeting']['k2']
		except:
			k2 = null

		try:
			k3 = data['adTargeting']['targeting']['k3']
		except:
			k3 = null

		try:
			count = data['conditionCount']
		except:
			count = 0

		s = "insert into symptom(symptom_name,summary,symptom_desc,k1,k2,k3,disease_count) values("+n+","+summary+","+desc+","+str(k1)+","+str(k2)+","+str(k3)+","+str(count)+");\n"
		#s="hi"
	except Exception as inst:
		print(type(inst))
		print(inst.args)
		print(inst)
		s = "\nerror for "+str(l[0])+"\n"
		print("error")
	
	return s


file = csv.reader(open('symptoms.csv'),delimiter=',')
f = open("symptomsInsert.txt","w")
line = 0
for i in file:
	line += 1
	print(str(line))
	s=get_json(i[0])
	f.write(s)
	if line%10==0:
		f.close()
		f=open("symptomsInsert.txt","a+")
		print("Opening file for write "+str(line))